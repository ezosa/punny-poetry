# Punny Poetry
Computational Creativity course (Fall 2020) at the University of Helsinki

Generate themed limericks!

Dependencies:
- wikipediaapi
- spacy
- editdistance

Starting point:

- python main.py 
- python main.py --theme Amsterdam

## Resources
- List of cities: https://datahub.io/core/world-cities, http://www.geonames.org/, https://github.com/lexman, https://okfn.org/